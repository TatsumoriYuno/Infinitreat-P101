-----
IMPORTANT INFORMATION
-----

SETTINGS REQUIREMENTS

UI Scaling: 110%
Resolution: 800x600
FullScreen: disabled/windowed
Geometry & Texture Details: Low
idk if bloom or shadows matter, but if they do, disable them

Usage:
0/prep: download autohotkey v2 and set your settings.
1. Open pirate101.
2. Go to an unpopulated area/realm so that you don't look weird to everyone else.
3. hit the + sign on your numpad.
4. Profit.